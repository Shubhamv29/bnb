<!-- insert the page content here -->
        <h1>Welcome to the Ongaonga Bed & Breakfast</h1>
        <p>The retired couple Mr and Mrs Smith have a large beautiful homestead in the Ongaonga Region. We live by ourselves have this beautifuly large heritage home which we have turned into a Bed & Breakfast (B&B). 
	  Our home is close to Napier, Waipukurau and Tikokino....</p>