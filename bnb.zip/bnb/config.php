<?php
//MySQL credentails
define("DBUSER","root");
define("DBPASSWORD","");
define("DBDATABASE","bnb");
define("DBHOST", "127.0.0.1");
?>